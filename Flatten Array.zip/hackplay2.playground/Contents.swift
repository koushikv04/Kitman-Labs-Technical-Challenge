//: Playground - noun: a place where people can play
//
//Below program is written to flatten a given input array to a single array
//
import UIKit


//Below function performs recursive action to remove values from all arrays and add the values to a single array and return the output to the user.
func bringItToOne(input:[Any])->[Any]
{
    //Final output array variable
    var outputArray = [Any]()
    for obj in input
    {
        //If object is an array, the object is given back to the same method unitl one array remains in the end and returns a single array and all the values are added to output array
        if ( obj is Array<Any>)
        {
            let returnedOutput = bringItToOne(input: obj as! Array )
            for val in returnedOutput
            {
                outputArray.append(val)
            }
        }
        else
        {
            //if not an array, the object is directly added to output array
            outputArray.append(obj)

        }
    }
    return outputArray
}
//Sample input
let input = [[1,[2,[3]]],[[4]]] as [Any]

//Function is called on given input and a single array is returned in the end to be displayed to the user
let onlyOneArray = bringItToOne(input: input )

print(onlyOneArray)
