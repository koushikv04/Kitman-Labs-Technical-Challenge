//: Playground - noun: a place where people can play

import UIKit


//Below function percorm recursive action to remove values from all arrays and add to a single array
func bringItToOne(input:[Any])->[Any]
{
    var outputArray = [Any]()
    for obj in input
    {
        if ( obj is Array<Any>)
        {
            let returnedOutput = bringItToOne(input: obj as! Array )
            for val in returnedOutput
            {
                outputArray.append(val)
            }
        }
        else
        {
            outputArray.append(obj)

        }
    }
    return outputArray
}
let input = [[1,[2,[3]]],[[4]]] as [Any]
let onlyOneArray = bringItToOne(input: input )
print(onlyOneArray)
