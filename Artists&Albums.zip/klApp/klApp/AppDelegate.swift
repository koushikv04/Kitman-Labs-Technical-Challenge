//
//  AppDelegate.swift
//  klApp
//
//  Created by Koushikv on 10/01/17.
//  Copyright © 2017 kv. All rights reserved.
//
//Abstract:
//The application delegate class used for setting up our data model and state restoration.
//
import UIKit

// MARK: - Types

//Extension of artist object to configure the cell

extension Artist {
    func configureCell(_ cell: ArtistCell) {
        cell.textLabel?.text = name
        cell.accessoryType = .disclosureIndicator
        
           }
}
//Extension of Album object to configure the cell

extension Album {
    func configureCell(_ cell: AlbumCell) {
        cell.textLabel?.text=""
        cell.detailTextLabel!.text = title
    }
}
//Enumeration for artist and album to add to recentitems array
enum RecentItem {
    case artist(Artist)
    case album(Album)
}

//Below extension ensure the right initialisation of cell and returned to cellforatrow() method
extension RecentItem {
    var cellDescriptor: CellDescriptor {
        switch self {
        case .artist(let artist):
            return CellDescriptor(reuseIdentifier: "artist", configure: artist.configureCell)
        case .album(let album):
            return CellDescriptor(reuseIdentifier: "album", configure: album.configureCell)
        }
    }
}
@UIApplicationMain

class AppDelegate: UIResponder, UIApplicationDelegate {

    // MARK: - Properties

    var window: UIWindow?
    var recentItems = [RecentItem]()
    
    // MARK: - Application Life Cycle

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool
    {

        self.fetchAlbumsAndArtists()
        //Items View Controller is allocated and added as rootviewcontroller to window in the below lines
        window = UIWindow(frame: UIScreen.main.bounds)
        let recentItemsVC = ItemsViewController(items: recentItems, cellDescriptor: { $0.cellDescriptor })
        let nc = UINavigationController(rootViewController: recentItemsVC)
        window?.rootViewController = nc
        window?.makeKeyAndVisible()
    
        // Override point for customization after application launch.
        
        return true
    }
    //Below function fetches the albums and artists from .json file from mainbundle and adds it to recentItems array
    func fetchAlbumsAndArtists()
    {
        //Constant containing the URL of albums.json file in mainbundle
        let jsonURL = Bundle.main.url(forResource: "albums", withExtension: "json")
        var jsonData:Data!
        do
        {
            //Data is fetched from the given URL
            jsonData = try Data(contentsOf: jsonURL!)
        }catch{
            print("data error")
        }
        //convert data to dictionary using JSONSerialisation in the below lines
        var root = [String:Any]()
        do
        {
            root = try JSONSerialization.jsonObject(with: jsonData, options: .allowFragments) as! Dictionary<String,Any>
        }catch
        {
            print("root error")
        }
        
        //Constants containing albums and artists array
        let albumsArray = root["albums"] as? Array<Any>
        let artistsArray = root["artists"] as? Array<Any>
        
       
       //Loop through each artists, fetch albums of each artists and add it to recentItems array in the below lines.
        for obj in artistsArray!
        {
            let artistDictionary = obj as! Dictionary<String,Any>
            
            var filteredAlbums=[Album]()
            let _ = albumsArray?.map({ a -> Void in
                let albumDict = a as! Dictionary<String,Any>
                //Albums are filtered for specific artists using ID as common factor
                if(albumDict["artist_id"]as?Int==artistDictionary["id"]as? Int)
                {
                    filteredAlbums.append(Album(title: (albumDict["title"] as? String)!))
                }
            })
            let artistItem:RecentItem = .artist(Artist(name: artistDictionary["name"] as! String,albums:filteredAlbums ))
            
            //The artist and their albums are added to recenitems array
            recentItems.append(artistItem)
        }
 
    }

    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }


}

