//
//  ArtistCell.swift
//  klApp
//
//  Created by Koushikv on 10/01/17.
//  Copyright © 2017 kv. All rights reserved.
//
//Abstract:
// Custom tableviewcell for Artist
//
import UIKit

class ArtistCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization cod
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    //Initialise tableviewcell in the below method with given string and cell type
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: .value1, reuseIdentifier: reuseIdentifier)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
