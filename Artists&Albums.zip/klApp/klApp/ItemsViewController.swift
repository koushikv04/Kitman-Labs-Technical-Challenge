//
//  ItemsViewController.swift
//  klApp
//
//  Created by Koushikv on 11/01/17.
//  Copyright © 2017 kv. All rights reserved.
//
//Abstract: Tableviewcontroller displays the albums and artists
//
import UIKit

// MARK: - Types

//Structure for album with title
struct Album {
    var title: String
}
//stucture containing name of the artist and array of albums
struct Artist {
    var name: String
    var albums:[Album]
}
//cell descriptor class which contains the constants and initiliases the tableviewcell
struct CellDescriptor {
    let cellClass: UITableViewCell.Type
    let reuseIdentifier: String
    let configure: (UITableViewCell) -> ()
    
    //Initialisation of cell descriptor
    init<Cell: UITableViewCell>(reuseIdentifier: String, configure: @escaping (Cell) -> ()) {
        self.cellClass = Cell.self
        self.reuseIdentifier = reuseIdentifier
        self.configure = { cell in
            configure(cell as! Cell)
        }
    }
}

class ItemsViewController<Item>: UITableViewController {
    
    // MARK: - Properties

    //Variables and constants for resueidentifer and cell descriptor
    var items: [Item] = []
    let cellDescriptor: (Item) -> CellDescriptor
    var didSelect: (Item) -> () = { _ in }
    var reuseIdentifiers: Set<String> = []
    
    //MARK: - Class initialisation
    //
    init(items: [Item], cellDescriptor: @escaping (Item) -> CellDescriptor) {
        self.cellDescriptor = cellDescriptor
        super.init(style: .plain)
        self.items = items
        self.title = "Artists and Albums"
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Tableview Delegate and Datasource
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return items.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        //Fecthing the current row object and cell descriptor using the same object
        let item = items[indexPath.row]
        let descriptor = cellDescriptor(item)
        
        //Register cell class for the first time and add it to resuseidentifiers
        if !reuseIdentifiers.contains(descriptor.reuseIdentifier) {
            tableView.register(descriptor.cellClass, forCellReuseIdentifier: descriptor.reuseIdentifier)
            reuseIdentifiers.insert(descriptor.reuseIdentifier)
        }
        //If registered, get details from reuseidentifers and return cell
        let cell = tableView.dequeueReusableCell(withIdentifier: descriptor.reuseIdentifier, for: indexPath)
        descriptor.configure(cell)
        return cell
    }
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        //Variables and constants to get the current row element
        var currentRow = indexPath.row
        let item = items[currentRow]
        let enumItem = item as! RecentItem
        //Checks if selected row is artist or album in the below lines
        switch enumItem
        {
            //if album selected, nothing is done
        case   .album(_):
            break
        //If artist, it is checked if to remove albums or display albums under the specific artist
        case let .artist(currentArtist):
            //Below if condition ensures that the last artist expands and displays the albums.
            if(items.count-1>currentRow)
            {
                // The Below lines of code checks if next row is artist or album. If album, we remove the albums under the artist from the table items else if artist, we add the albums under the artist to the table to display to the user.
                currentRow += 1
                let nextItem = items[currentRow] as! RecentItem
                switch nextItem
                {
                case   .album(_):
                    //Remove albums from current row to count of number of albums available in Artist structure
                    items.removeSubrange(ClosedRange(uncheckedBounds: (lower: currentRow, upper: currentRow+currentArtist.albums.count-1)))

                    //Reload table after removing albums from items array
                    self.tableView.reloadData()
                    
                    
                case  .artist(_):
                    //Add all albums under the artist to items array
                    for oneAlbum in currentArtist.albums
                    {
                        let albumAddition:RecentItem = .album(oneAlbum)
                        items.insert(albumAddition as! Item, at: currentRow)
                    }
                    //Reload table after inserting albums to items array

                    self.tableView.reloadData()
                    
                    
                }

            }
            else
            {
                //This part of code is called specifically for last artist to append the albums to the end of the items array instead of insert at specific location
                for oneAlbum in currentArtist.albums
                {
                    let albumAddition:RecentItem = .album(oneAlbum)
                    items.append(albumAddition as! Item)
                }
                //Reload table after appending albums to items array
                self.tableView.reloadData()
            }
        
        }
       
        didSelect(item)
    }
    
   
   
    
}

